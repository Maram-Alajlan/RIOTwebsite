<?php
/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "riot";

// Create connection
$dbconn = new mysqli($servername, $username, $password, $dbname);
*/

$servername = "mysql.dronemap.coins-lab.org";
$username = "akoubaa";
$password = "ccis2010";
$dbname = "riot";

// Create connection
$dbconn = new mysqli($servername, $username, $password, $dbname);


?>